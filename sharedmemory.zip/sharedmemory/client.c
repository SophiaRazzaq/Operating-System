#include <iostream>
#include <vector>
#include <unistd.h>
#include <stdio.h>
#include <sys/shm.h>
#include <fcntl.h>

using namespace std;

int main(int argc, char* arg[])

{
    vector<int> vec;
    bool found = false;
    int v = 0;
    int* point = nullptr;

    int f = open(arg[1], O_RDONLY);             
    int n = lseek(f,0,SEEK_END);
    f =open(arg[1], O_RDONLY); 

    char* array = new char[n];
    read(f, array, n);
    close(f);

    for(int i=0; array[i]!='\0';i++)         //
    {
        if(array[i]>='0' && array[i]<='9')

        {
            v *=10;
            v +=array[i]-'0';
            found=true;

        }

        else if(found)
        {
            cout << "Number in files: " << v << endl;
            vec.push_back(v);
            v =0;
            found=false;
        }

    }
    if(v !=0)

    { 
        cout << "Values : " << v << endl;
        vec.push_back(v);
    }

    int key = shmget(1,sizeof(int)* vec.size(),IPC_CREAT | IPC_EXCL | 0666);
    point = (int*)shmat(key,NULL,0);
    point[0] = vec.size();

    for(int j=0; j < vec.size(); j++)
    {
        point[j +1]= vec[j];
    }

    cout << "Detaching: " << shmdt(point) << endl;

}