#include <iostream>
#include <string>
#include <sys/shm.h>

using namespace std;

int main()

{
    int* point = nullptr;
    int value=shmget(1, 32, 0 );

    point =  (int*)shmat(value,NULL,0);

    float avg=0.0;
    int total_sum=0;

    int tot = point[0];

    

    for(int j=1;j<= tot;j++)

    {

        cout << point[j] << endl;

        total_sum = total_sum + point[j];

    }
    avg = total_sum / tot;

    cout << "Sum of numbers is: " << total_sum << endl;
    if(tot > 0)

    {

        cout << "Average : " << avg << endl;

    }

    cout << "Detaching: " << shmdt(point) << endl;

    cout << "Deletion: : " << shmctl(value, IPC_RMID, NULL) << endl;

}

